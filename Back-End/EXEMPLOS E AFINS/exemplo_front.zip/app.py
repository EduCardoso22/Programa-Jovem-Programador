# importação da biblioteca do flask 
# jsonify para resposta do servidor
# request capturar as requisições 
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import datetime

# construindo a aplicação web com o Flask
app = Flask(__name__)
CORS(app)


@app.route("/")
def principal():

    lista_gostos = [
                {"item":1, "nome":"dormir"},
                {"item":2, "nome":"comer"}
            ]


    return render_template("teste.html", lista=lista_gostos)


if __name__ == "__main__":
    #habilitando o log no console das solicitações
    app.run(debug=True)
